<?php
	 session_start();
	 $conn = mysqli_connect("localhost","root","","web");
	 $count = $_SESSION['user_email'];
   $query = "SELECT * FROM users WHERE email = '$count'";
	 $result = mysqli_query($conn, $query);
	 $row = mysqli_fetch_assoc($result);
?>
<header class="header">
	<div class="container">
		<div class="row">
			<div class="col-md-4 ">
				<div class="navbar-header">
					    <button type="button" class="navbar-toggle menu-button" data-toggle="collapse" data-target="#myNavbar">
					        <span class="glyphicon glyphicon-align-justify"></span>
					    </button>
      					<a class="navbar-brand logo" href="#"></a>
    			</div>
			</div>
			<div class="col-md-8">
				<nav class="collapse navbar-collapse" id="myNavbar" role="navigation">
					<ul class="nav navbar-nav menu">
							<li><a href="#page-top" class="page-scroll active">Home</a></li>
							<li><a href="#section2" class="page-scroll">Features</a></li>
							<li><a href="#work" class="page-scroll">Portfolio</a></li>
							<li><a href="#section4" class="page-scroll">Contact</a></li>
							<li><a href="login.php">SIGN IN</a></li>
					</ul>
          <ul class="collapse nav  menu navbar-collapse navbar-nav">
  		            <li class="dropdown">
  		              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
  					               <span class="glyphicon glyphicon-user"></span>&nbsp;Hello <?= $row['name']; ?>&nbsp;<span class="caret"></span></a>
  		              <ul class="dropdown-menu">
  		              	<?php
											
  		              		if($count == "admin"){?>
  		              			<li><a href="admin-part/retrieve.php"><span class="glyphicon glyphicon-pencil"></span>&nbsp;Add Product</a></li>
  		              			<li><a href="profile.php"><span class="glyphicon glyphicon-user"></span>&nbsp;View Profiles</a></li>
  		                		<li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span>&nbsp;Sign Out</a></li>
  		              		<?php
                              }?>
                          	<?php if($count != "admin"){?>
  				                <li><a href="profile.php"><span class="glyphicon glyphicon-user"></span>&nbsp;View Profile</a></li>
  				                <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span>&nbsp;Sign Out</a></li>
  				            <?php
                              }?>
  		              </ul>
  		            </li>
  		        </ul>
				</nav>
			</div>
		</div>
	</div>
</header>
