<?php
	session_start();
	require 'db.php';

	if ( !empty($_POST)) {

		$username = $_POST['username'];
		$email = $_POST['email'];
		$password = $_POST['password'];
		$password_confirm = $_POST['password_confirm'];
		$_SESSION['pass'] = $_POST['password'];

		$valid = true;

		if ($valid && $password_confirm == $password && strlen($password) >= 6) {
			$sql = "INSERT INTO users (name,email,password) values(?, ?, ?)";

			$q = $db_con->prepare($sql);
			$q->execute(array($username,$email,$password));

			$_SESSION['user_email'] = $email;
			header("Location: login.php");
		}
		elseif ($password_confirm != $password) {
			$password_confirmError = "Doesn't match";
			$valid = false;
		}
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">

</head>
<script type="text/javascript">
  function checkForm() {
  // Fetching values from all input fields and storing them in variables.
  var name = document.getElementById("username1").value;
  var password = document.getElementById("password1").value;
  var email = document.getElementById("email1").value;
  var website = document.getElementById("password_confirm1").value;
  //Check input Fields Should not be blanks.
  if (name == '' || password == '' || email == '' || website == '') {
    alert("Fill All Fields");
  } else {
    //Notifying error fields
    var username1 = document.getElementById("username");
    var password1 = document.getElementById("password");
    var email1 = document.getElementById("email");
    var website1 = document.getElementById("password_confirm");
    //Check All Values/Informations Filled by User are Valid Or Not.If All Fields Are invalid Then Generate alert.
    if (username1.innerHTML == 'Must be 3+ letters' || password1.innerHTML == 'Password too short' || email1.innerHTML == 'Invalid email' || website1.innerHTML == 'Doesnt match') {
      alert("Fill Valid Information");
    } else {
    //Submit Form When All values are valid.
      document.getElementById("myForm").submit();
      }
    }
  }
  function validate(field, query) {
  var xmlhttp;
  if (window.XMLHttpRequest) { // for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp = new XMLHttpRequest();
  } else { // for IE6, IE5
    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange = function() {
  if (xmlhttp.readyState != 4 && xmlhttp.status == 200) {
    document.getElementById(field).innerHTML = "Validating..";
  } else if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
      document.getElementById(field).innerHTML = xmlhttp.responseText;
  } else {
    document.getElementById(filed).innerHTML = "Error Occurred. <a href='index.php'>Reload Or Try Again</a> the page.";
    }
  }
  xmlhttp.open("GET", "validation.php?field=" + field + "&query=" + query, false);
  xmlhttp.send();
  }
</script>
<style type="text/css">
	span{
	color:green
	}
	.login-form-1 .form-group div{
	color:red;
	font-size:14px
	}
</style>
<body>
    <!-- REGISTRATION FORM -->
<div class="text-center" style="padding:50px 0">
	<div class="logo">registration</div>
	<!-- Main Form -->
	<div class="login-form-1">
		<form id="register-form" class="text-left" method= "post" action=""  id="myForm" action="" name="myForm">
			<div class="login-form-main-message"></div>
			<div class="main-login-form">
				<div class="login-group">
					<div class="form-group">
						<label for="reg_username" class="sr-only">Username</label>
						<input type="text" class="form-control" id="username1" name="username" onblur="validate('username', this.value)"  placeholder="username">
            <strong><div id="username"></div></strong>
					</div>
          <div class="form-group">
						<label for="reg_email" class="sr-only">Email</label>
						<input type="text" class="form-control" id="email1" name="email" onblur="validate('email', this.value)" placeholder="email">
            <strong><div id="email"></div></strong>
					</div>
					<div class="form-group">
						<label for="reg_password" class="sr-only">Password</label>
						<input type="password" class="form-control" id="password1" name="password"  onblur="validate('password', this.value)" placeholder="password">
            <strong><div id="password"></div></strong>
					</div>
					<div class="form-group">
						<label for="reg_password_confirm" class="sr-only">Password Confirm</label>
						<input type="password" class="form-control" id="password_confirm1" name="password_confirm" onblur="validate('password_confirm', this.value)" placeholder="confirm password">
            <strong><div id="password_confirm"></div></strong>
					</div>
				</div>
				<button type="submit" class="login-button" onclick="checkForm()" name='submit'><i class="fa fa-chevron-right"></i></button>
			</div>
			<div class="etc-login-form">
				<p>already have an account? <a href="login.php">login here</a></p>
			</div>
		</form>
	</div>

</div>
</body>
</html>
