<?php
	session_start();
	$con = mysqli_connect('localhost','root','','web') or die("Unable to connect");

	if(isset($_POST['submit'])){
		$user_email = $_POST['useremail'];
		$user_password = $_POST['password'];

		$sql = mysqli_query($con,"SELECT * from users where  email=\"$user_email\" and password=\"$user_password\"");
		if (mysqli_num_rows($sql)) {

			$_SESSION['user_email'] = $user_email;

			header('location:index.php');
		}else{
			header('location:login.php');
		}
	}
?>
