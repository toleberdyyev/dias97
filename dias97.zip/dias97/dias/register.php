<?php
 session_start();
mysql_connect("localhost", "root", "") or die(mysql_error()); // Connect to database server(localhost) with username and password.
mysql_select_db("test") or die(mysql_error()); 
// Check connection

    
 if(isset($_POST['name']) && !empty($_POST['name']) AND isset($_POST['email']) && !empty($_POST['email'])){
    $name = $_POST['name']; // Turn our post into a local variable
    $email = $_POST['email']; // Turn our post into a local variable
    $pass = $_POST['pass']; // Turn our post into a local variable
     if(!eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$", $email)){
    // Return Error - Invalid Email
    $_SESSION['error'] =  'The email you have entered is invalid, please try again.';
}
     
     else{
    // Return Success - Valid Email
    
         
         $hash = md5( rand(0,1000) );
     mysql_query("INSERT INTO users (username, password, email, hash) VALUES(
'".$name ."', 
'". md5($pass) ."', 
'".$email ."', 
'".$hash ."') ") or die(mysqli_error());    
$to      = $email; // Send email to our user
$subject = 'Signup | Verification'; // Give the email a subject 
$message = '
 
Thanks for signing up!
Your account has been created, you can login with the following credentials after you have activated your account by pressing the url below.
 
------------------------
Username: '.$name.'
Password: '.$password.'
------------------------
 
Please click this link to activate your account:
http://www.yourwebsite.com/verify.php?email='.$email.'&hash='.$hash.'
 
'; // Our message above including the link
                     
$headers = 'From:noreply@yourwebsite.com' . "\r\n"; // Set from headers
mail($to, $subject, $message, $headers); // Send our email     
    header('Location: success.php');     
}
}           
?>
